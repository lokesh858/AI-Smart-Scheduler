
AI Smart Scheduler - Full Version (Gmail + Telegram + Twilio + OpenAI)

What's included:
- Django backend with APIs to generate AI messages and schedule them
- APScheduler management command to send scheduled messages (email, telegram, whatsapp, sms)
- React frontend (simple UI) to create topics, generate AI options, and schedule messages
- senders.py handles Gmail SMTP, Telegram Bot API, and Twilio for WhatsApp/SMS

Important steps to run (Windows):
1. Unzip and open terminal
2. cd backend
3. python -m venv venv
4. venv\Scripts\activate
5. pip install -r requirements.txt
6. pip install python-dotenv python-telegram-bot==13.15
7. Copy .env.sample -> .env and fill credentials (OPENAI_API_KEY, GMAIL, TELEGRAM, TWILIO)
8. python manage.py migrate
9. python manage.py runserver
10. In new terminal (venv active): python manage.py runapscheduler
11. cd ../frontend
12. npm install
13. npm start

Testing tips:
- For Telegram: create bot via @BotFather. Message the bot from your account and use getUpdates to find chat_id, or put your chat id in .env.
- For Gmail: use App Password (recommended) and set GMAIL_APP_PASSWORD in .env.
- For Twilio: configure WhatsApp sandbox or your Twilio number and set TWILIO_WHATSAPP_FROM and TWILIO_SMS_FROM.
