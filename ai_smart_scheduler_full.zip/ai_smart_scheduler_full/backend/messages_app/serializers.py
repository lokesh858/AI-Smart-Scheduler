
from rest_framework import serializers
from .models import ScheduledMessage
class ScheduledMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ScheduledMessage
        fields = '__all__'
