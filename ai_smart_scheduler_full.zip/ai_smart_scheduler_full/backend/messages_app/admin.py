from django.contrib import admin
from .models import ScheduledMessage
admin.site.register(ScheduledMessage)
