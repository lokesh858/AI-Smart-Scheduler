
from django.db import models
from django.contrib.auth.models import User
class ScheduledMessage(models.Model):
    PLATFORM_CHOICES = [('whatsapp','WhatsApp'),('telegram','Telegram'),('email','Email'),('sms','SMS')]
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    recipient = models.CharField(max_length=255)
    platform = models.CharField(max_length=20, choices=PLATFORM_CHOICES)
    message_text = models.TextField()
    scheduled_time = models.DateTimeField()
    sent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f'{self.platform} to {self.recipient} at {self.scheduled_time}'
