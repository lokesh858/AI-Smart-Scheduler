
import os, requests, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv
load_dotenv()

GMAIL_EMAIL = os.getenv('GMAIL_EMAIL')
GMAIL_APP_PASSWORD = os.getenv('GMAIL_APP_PASSWORD')
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN')
TWILIO_WHATSAPP_FROM = os.getenv('TWILIO_WHATSAPP_FROM')  # e.g. 'whatsapp:+1415xxxx'
TWILIO_SMS_FROM = os.getenv('TWILIO_SMS_FROM')  # e.g. '+1xxxx'

def send_email(recipient_email, subject, body_text):
    if not GMAIL_EMAIL or not GMAIL_APP_PASSWORD:
        print('Gmail not configured. Skipping email send.')
        return False
    try:
        msg = MIMEMultipart()
        msg['From'] = GMAIL_EMAIL
        msg['To'] = recipient_email
        msg['Subject'] = subject or 'Scheduled Message'
        msg.attach(MIMEText(body_text, 'plain'))
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(GMAIL_EMAIL, GMAIL_APP_PASSWORD)
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        print('Email send error:', e)
        return False

def send_telegram(chat_id, text):
    token = TELEGRAM_BOT_TOKEN
    if not token:
        print('Telegram bot token missing.')
        return False
    cid = chat_id or os.getenv('TELEGRAM_CHAT_ID')
    if not cid:
        print('No chat id provided for Telegram.')
        return False
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    try:
        r = requests.post(url, data={'chat_id': cid, 'text': text}, timeout=10)
        return r.status_code == 200
    except Exception as e:
        print('Telegram send error:', e)
        return False

def send_twilio_whatsapp(to_whatsapp, body):
    try:
        from twilio.rest import Client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        message = client.messages.create(body=body, from_=TWILIO_WHATSAPP_FROM, to=to_whatsapp)
        return True if message.sid else False
    except Exception as e:
        print('Twilio WhatsApp error:', e)
        return False

def send_twilio_sms(to_phone, body):
    try:
        from twilio.rest import Client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        message = client.messages.create(body=body, from_=TWILIO_SMS_FROM, to=to_phone)
        return True if message.sid else False
    except Exception as e:
        print('Twilio SMS error:', e)
        return False
