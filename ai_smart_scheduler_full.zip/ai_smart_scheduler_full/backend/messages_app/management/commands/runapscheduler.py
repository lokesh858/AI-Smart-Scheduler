
from django.core.management.base import BaseCommand
from apscheduler.schedulers.background import BackgroundScheduler
import django, os, time, datetime
os.environ.setdefault('DJANGO_SETTINGS_MODULE','ai_scheduler.settings')
django.setup()
from messages_app.models import ScheduledMessage
from messages_app.senders import send_email, send_telegram, send_twilio_whatsapp, send_twilio_sms

def job_check():
    now = datetime.datetime.now(datetime.timezone.utc)
    due = ScheduledMessage.objects.filter(sent=False, scheduled_time__lte=now)
    for m in due:
        text = m.message_text
        print(f"Attempting send {m.platform} to {m.recipient}: {text}")
        success = False
        try:
            if m.platform == 'email':
                success = send_email(m.recipient, 'Scheduled message', text)
            elif m.platform == 'telegram':
                success = send_telegram(m.recipient, text)
            elif m.platform == 'whatsapp':
                success = send_twilio_whatsapp(m.recipient, text)
            elif m.platform == 'sms':
                success = send_twilio_sms(m.recipient, text)
            else:
                print('Unknown platform', m.platform)
            if success:
                print('SENT successfully')
                m.sent = True
            else:
                print('Send failed')
        except Exception as e:
            print('Send exception', e)
        finally:
            m.save()

class Command(BaseCommand):
    help = 'Run APScheduler to send scheduled messages'
    def handle(self, *args, **options):
        scheduler = BackgroundScheduler(timezone='UTC')
        scheduler.add_job(job_check, 'interval', seconds=10)
        scheduler.start()
        print('APScheduler started.')
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            scheduler.shutdown()
