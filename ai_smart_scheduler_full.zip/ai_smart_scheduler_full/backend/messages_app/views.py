
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from .models import ScheduledMessage
from .serializers import ScheduledMessageSerializer
from django.contrib.auth.models import User
import datetime, os

@api_view(['POST'])
@permission_classes([AllowAny])
def generate_message(request):
    data = request.data
    topic = data.get('topic', 'Hello')
    style = data.get('style', 'friendly')
    OPENAI_KEY = os.getenv('OPENAI_API_KEY')
    if OPENAI_KEY:
        try:
            import openai
            openai.api_key = OPENAI_KEY
            prompt = f"Generate 3 short {style} messages for: {topic}"
            resp = openai.ChatCompletion.create(model='gpt-3.5-turbo', messages=[{'role':'user','content':prompt}], max_tokens=150, n=3, temperature=0.8)
            options = [c['message']['content'].strip() for c in resp['choices']]
        except Exception as e:
            options = [f"(OpenAI error) {str(e)}", "Please check your key."]
    else:
        options = [
            f"Happy Birthday my love! {topic} - Option 1 ({style})",
            f"Wishing you a beautiful birthday filled with love. {topic} - Option 2 ({style})",
            f"To my dearest, happiest birthday wishes. {topic} - Option 3 ({style})"
        ]
    return Response({'options': options})

@api_view(['POST'])
@permission_classes([AllowAny])
def schedule_message(request):
    data = request.data
    user_id = data.get('user_id', None)
    user = None
    if user_id:
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            user = None
    recipient = data.get('recipient')
    platform = data.get('platform')
    message_text = data.get('message_text')
    scheduled_time = data.get('scheduled_time')
    try:
        scheduled_time = datetime.datetime.fromisoformat(scheduled_time)
    except Exception:
        return Response({'error':'bad date format'}, status=400)
    sm = ScheduledMessage.objects.create(user=user, recipient=recipient, platform=platform, message_text=message_text, scheduled_time=scheduled_time)
    serializer = ScheduledMessageSerializer(sm)
    return Response(serializer.data)

from rest_framework import generics
class ScheduledList(generics.ListAPIView):
    queryset = ScheduledMessage.objects.all().order_by('-scheduled_time')
    serializer_class = ScheduledMessageSerializer
