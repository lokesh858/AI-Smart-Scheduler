
from django.urls import path
from . import views
urlpatterns = [
    path('generate/', views.generate_message),
    path('schedule/', views.schedule_message),
    path('scheduled/', views.ScheduledList.as_view()),
]
