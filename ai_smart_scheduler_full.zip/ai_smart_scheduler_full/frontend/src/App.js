
import React, {useState} from 'react';
import axios from 'axios';
function App(){
  const [topic,setTopic]=useState('');
  const [style,setStyle]=useState('romantic');
  const [options,setOptions]=useState([]);
  const [selected,setSelected]=useState('');
  const [recipient,setRecipient]=useState('');
  const [platform,setPlatform]=useState('telegram');
  const [scheduledTime,setScheduledTime]=useState('');
  const generate = async ()=>{
    const res = await axios.post('http://127.0.0.1:8000/api/generate/', {topic, style});
    setOptions(res.data.options || []);
  }
  const schedule = async ()=>{
    if(!selected) return alert('Select option');
    const payload = {user_id:null, recipient, platform, message_text:selected, scheduled_time:scheduledTime};
    await axios.post('http://127.0.0.1:8000/api/schedule/', payload);
    alert('Scheduled. Start scheduler to send.');
  }
  return (
    <div style={{padding:20,maxWidth:800,margin:'auto'}}>
      <h2>AI Smart Scheduler</h2>
      <div><label>Topic</label><input value={topic} onChange={e=>setTopic(e.target.value)} style={{width:'100%'}}/></div>
      <div style={{marginTop:8}}><label>Style</label><select value={style} onChange={e=>setStyle(e.target.value)}><option value="romantic">Romantic</option><option value="polite">Polite</option><option value="professional">Professional</option></select></div>
      <div style={{marginTop:8}}><button onClick={generate}>Generate Options</button></div>
      <div style={{marginTop:12}}><h4>Options</h4>{options.map((o,i)=>(<div key={i} style={{border:'1px solid #ddd',padding:8,marginBottom:6}}><input type="radio" name="opt" onChange={()=>setSelected(o)}/> <span>{o}</span></div>))}</div>
      <div style={{marginTop:8}}><label>Recipient</label><input value={recipient} onChange={e=>setRecipient(e.target.value)} style={{width:'100%'}} placeholder="email or telegram chat id or whatsapp:+9199..." /></div>
      <div style={{marginTop:8}}><label>Platform</label><select value={platform} onChange={e=>setPlatform(e.target.value)}><option value="telegram">Telegram</option><option value="email">Email</option><option value="whatsapp">WhatsApp</option><option value="sms">SMS</option></select></div>
      <div style={{marginTop:8}}><label>Scheduled Time (ISO)</label><input value={scheduledTime} onChange={e=>setScheduledTime(e.target.value)} style={{width:'100%'}} placeholder="2025-10-28T09:30:00"/></div>
      <div style={{marginTop:8}}><button onClick={schedule}>Schedule</button></div>
    </div>
  )
}
export default App;
